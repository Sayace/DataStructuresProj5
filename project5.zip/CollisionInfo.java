package project5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * The CollisionInfo class contains the main method which will open the file, read file,
 * make objects, store information, obtain user input, and also handles exceptions
 * 
 * @author Alice Han
 *
 */
public class CollisionInfo {
	public static void main(String args[]) throws Exception {
		//if the argument is not given then we print out error message and exit
		if (args.length==0) {
			System.err.println("Error: file name needed as an argument");
			System.exit(0);
		}
		//create the new file object
		File file = new File(args[0]);
		//if the does not exist we print out the error message
		if (!file.exists()){
		   System.err.println(args[0]+ ": This file does not exist");
		   System.exit(1);
		}
		//we create Scanner and CollisionsData
	    Scanner in=null;
	    CollisionsData collisionsTree = new CollisionsData();
	    //We try to make a new file and if an exception is thrown then we catch
	    try {
	    	in = new Scanner(file);
	    }
	    //if the file is not found we use the FileNotFoundException and print out an error message
	    catch (FileNotFoundException e1){
	    	System.err.print("Error: File not found.");
	    	System.exit(0);
	    }
	  //if the file cannot be read we use the IllegalStateException and print out an error message
	    catch (IllegalStateException e2) {
	    	System.err.print("Error: File cannot be read.");
	    	System.exit(0);
	    }
	    finally {
	    	//if the try passes then we read through the file until there is no next line
			while (in.hasNextLine()){
				//create a string to store the line of text
		    	String line = in.nextLine();
		    	//we create the SplitLineMethod object
		    	SplitLineMethod splitter = new SplitLineMethod();
		    	//if the line does not have 24-29 entries we skip this line
		    	if(splitter.splitCSVLine(line).size()<24||splitter.splitCSVLine(line).size()>29) {
			    	continue;
		    	}
		    	//test if collision object can be made with the new ArrayList we split
		    	try {
		    		Collision collisionEntry=new Collision(splitter.splitCSVLine(line));
		    		//add to CollisionData object
			    	collisionsTree.add(collisionEntry);
		    	}
		    	//if we find problem with the line we skip it
		    	catch(Exception e) {
		    		continue;
		    	}
	    	}
	    }
	    //close this scanner
	    in.close();
	    
	    //We will deal with user input here
	    //Create new scanner object to read user input
	    Scanner userIn= new Scanner(System.in);
	    //create boolean checker
	    boolean checker=true;
	    //ask for user input until they quit
	    while(checker) {
	    	//Print out user prompt for zipcode
			System.out.print("Enter a zipcode ('quit' to exit): ");
			//stores user input into string
			String zipInput=userIn.next();
			//if user wants to quit we let the program end
			if (zipInput.equals("quit")) {
				checker=false;
			  	continue;
			}
			//check if input is all digits
			try {
				Integer.parseInt(zipInput);
		    }
		    //if the zipcode input is not valid we catch and print error message
	    	catch (IllegalArgumentException e) {
	    		System.err.println("\nInvalid zipcode. Try again.\n");
	    		continue;
	    	}
			int testZip= Integer.parseInt(zipInput);
			//if zipcode is not 5 digits or negative number we throw exception
			if(zipInput.length() != 5 || testZip<0) {
				System.err.println("Invalid zipcode. Try again.\n");
	    		continue;
			}
			
			//Print out user prompt for begin date
			System.out.print("Enter start date (MM/DD/YYYY): ");
			//stores user input into string
			String startInput=userIn.next();
			
			//Print out user prompt for end date
			System.out.print("Enter end date (MM/DD/YYYY): ");
			//stores user input into string
			String endInput=userIn.next();
			//check if the input can create date objects
			try {
				Date begin=new Date(startInput);
				Date end=new Date(endInput);
			}
			//if invalid input we return error message
			catch(IllegalArgumentException e) {
				System.err.println("\nInvalid date format. Try again.\n");
	    		continue;
			}
			//create new date objects
			Date begin=new Date(startInput);
			Date end=new Date(endInput);
			System.out.println("");
			//print out report by calling get report
			System.out.print(collisionsTree.getReport(zipInput, begin, end));
	    }
	    
	    //close the scanner
	    userIn.close();
    }
}
