/* * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * This code should not be distributed outside of the
 * CSCI-102 class. 
 * * * * * * * * * * * * * * * * * * * * * * * * * * */

package project5;

import java.util.ArrayList;

/**
 * The class creates a CollisionData object which is an AVL tree that stores Collision objects
 * while using methods that update height, calculate balance factor, add to the tree,
 * remove from the tree, and balance the tree as well as printing out the tree and report
 * 
 * Based on BST_Recursive class provided by Professor Joanna Klukowska
 * 
 * @author Alice Han
 *
 */
public class CollisionsData {

	// root of the tree
	protected Node<Collision> root;
	// current number of nodes in the tree
	protected int numOfElements;
	//helper variable used by the remove methods 
	private boolean found;

	/**
	 * Default constructor that creates an empty tree.
	 */
	public CollisionsData() {
		//sets root to null and numOfElements to 0
		this.root = null;
		numOfElements = 0;
	}

	/**
	 * Add the given data item to the tree. If item is null, the tree does not
	 * change. If item already exists, the tree does not change. 
	 * 
	 * @param item the new element to be added to the tree
	 */
	public void add(Collision item) {
		//if item is null tree does not change
		if (item == null)
			return;
		//sets root to new addition to tree by calling the recursive add method
		root = add (root, item);
		
	}

	/*
	 * Actual recursive implementation of add.  
	 * 
	 * @param item the new element to be added to the tree
	 * @return Node<Collision> the root node of the balanced tree
	 */
	private Node<Collision> add(Node<Collision> node, Collision item) {
		//if the node is null we add the new item by returning it and increment numOfElements
		if (node == null) { 
			numOfElements++;
			return new Node<Collision>(item);
		}
		//if the node we're looking at has data bigger than item we add item in the left subtree
		if (node.data.compareTo(item) > 0) {
			//we add item in the left subtree
			node.left = add(node.left, item);
			//update height of the current node
			updateHeight(node);
			//if the balance factor is -2, we move to the left child
			if(balanceFactor(node)<=-2) {
				//if the balance factor of this child is -1 we perform left left rotation
				if(balanceFactor(node.left)<0) {
					return balanceLL(node);
				}
				//if the balance factor of this child is 1 we perform left right rotation
				if(balanceFactor(node.left)>0) {
					return balanceLR(node);
				}
			}
		}
		//if the node we're looking at has data smaller than item we add item in the right subtree
		else if (node.data.compareTo(item) < 0) {
			//we add item in the right subtree
			node.right = add(node.right, item);
			//update height of the current node
			updateHeight(node);
			//if the balance factor is 2, we move to the right child
			if(balanceFactor(node)>=2) {
				//if the balance factor of this child is -1 we perform right left rotation
				if(balanceFactor(node.right)<0) {
					return balanceRL(node);
				}
				//if the balance factor of this child is 1 we perform right right rotation
				if(balanceFactor(node.right)>0) {
					return balanceRR(node);
				}
			}
		}
		//return the node of the new root of the tree
		return node; 
	}

	/**
	 * Remove the item from the tree. If item is null the tree remains unchanged. If
	 * item is not found in the tree, the tree remains unchanged.
	 * 
	 * @param target the item to be removed from this tree 
	 * @return true when target to be removed is found/removed
	 */
	public boolean remove(Collision target)
	{
		//set the root to new root of tree after recursive remove method is called
		root = recRemove(target, root);
		return found;
	}


	/*
	 * Actual recursive implementation of remove method: find the node to remove.  
	 * 
	 * @param target the item to be removed from this tree 
	 * @return Node<Collision> the root node of the balanced tree
	 */
	private Node<Collision> recRemove(Collision target, Node<Collision> node)
	{
		//if the node is null it is not found and we return false
		if (node == null)
			found = false;
		//if target is smaller than the node we are looking at go down the left subtree
		else if (target.compareTo(node.data) < 0) {
			node.left = recRemove(target, node.left);
			//update height of the node
			updateHeight(node);
			//if the balance factor is -2 we move to the left child
			if(balanceFactor(node)<=-2) {
				//if the balance factor of this child is -1 we perform left left rotation
				if(balanceFactor(node.left)<0) {
					return balanceLL(node);
				}
				//if the balance factor of this child is 1 we perform left right rotation
				if(balanceFactor(node.left)>0) {
					return balanceLR(node);
				}
			}
		}
		//if target is bigger than the node we are looking at go down the right subtree
		else if (target.compareTo(node.data) > 0) {
			node.right = recRemove(target, node.right );
			//update height of the node
			updateHeight(node);
			//if the balance factor is 2 we move to the right child
			if(balanceFactor(node)>=2) {
				//if the balance factor of this child is -1 we perform right left rotation
				if(balanceFactor(node.right)<0) {
					return balanceRL(node);
				}
				//if the balance factor of this child is 1 we perform right right rotation
				if(balanceFactor(node.right)>0) {
					return balanceRR(node);
				}
			}
		}
		//if the above if statements fail then we have reached the target node
		else {
			//we set the node to the new node it should be after tree is modified
			node = removeNode(node);
			//decrement numOfElements
			numOfElements--;
			//set found to true
			found = true;
		}
		//return the new root of the tree after removal method finished
		return node;
	}
	
	/*
	 * Actual recursive implementation of remove method: perform the removal.  
	 * 
	 * @param target the item to be removed from this tree 
	 * @return a reference to the node itself, or to the modified subtree 
	 */
	private Node<Collision> removeNode(Node<Collision> node)
	{
		//creates collision object
		Collision data;
		//if left child is null we replace the node with the right child
		if (node.left == null)
			return node.right ;
		//if right child is null we replace the node with the left child
		else if (node.right  == null)
			return node.left;
		//if both children exist
		else {
			//then we call getPredecessor on the left child and set the node to the result
			data = getPredecessor(node.left);
			node.data = data;
			//perform recRemove on the left child to fix the subtree
			node.left = recRemove(data, node.left);
			return node;
		}
	}
	
	/*
	 * Returns the information held in the rightmost node of subtree  
	 * 
	 * @param subtree root of the subtree within which to search for the rightmost node 
	 * @return returns data stored in the rightmost node of subtree  
	 */
	private Collision getPredecessor(Node<Collision> subtree)
	{
		if (subtree==null) throw new NullPointerException("getPredecessor called with an empty subtree");
		Node<Collision> temp = subtree;
		while (temp.right  != null)
			temp = temp.right ;
		return temp.data;
	}



	/**
	 * Determines the number of elements stored in this BST.
	 * 
	 * @return number of elements in this BST
	 */
	public int size() {
		return numOfElements;
	}

	/**
	 * Returns a string representation of this tree using an inorder traversal . 
	 * @see java.lang.Object#toString()
	 * @return string representation of this tree 
	 */
	public String toString() {
		StringBuilder s = new StringBuilder();
		inOrderPrint(root, s);
		return s.toString();
	}

	/*
	 * Actual recursive implementation of inorder traversal to produce string
	 * representation of this tree.
	 * 
	 * @param tree the root of the current subtree
	 * @param s the string that accumulated the string representation of this BST
	 */
	private void inOrderPrint(Node<Collision> tree, StringBuilder s) {
		if (tree != null) {
			inOrderPrint(tree.left, s);
			s.append(tree.data.toString() + "  ");
			inOrderPrint(tree.right , s);
		}
	}

	/**
	 * Produces tree like string representation of this BST.
	 * @return string containing tree-like representation of this BST.
	 */
	public String toStringTreeFormat() {
		//creates new stringbuilder object
		StringBuilder s = new StringBuilder();
		//calls preOrderPrint
		preOrderPrint(root, 0, s);
		return s.toString();
	}

	/*
	 * Actual recursive implementation of preorder traversal to produce tree-like string
	 * representation of this tree.
	 * 
	 * @param tree the root of the current subtree
	 * @param level level (depth) of the current recursive call in the tree to
	 *   determine the indentation of each item
	 * @param output the string that accumulated the string representation of this
	 *   BST
	 */
	private void preOrderPrint(Node<Collision> tree, int level, StringBuilder output) {
		if (tree != null) {
			String spaces = "\n";
			if (level > 0) {
				for (int i = 0; i < level - 1; i++)
					spaces += "   ";
				spaces += "|--";
			}
			output.append(spaces);
			output.append(tree.data);
			preOrderPrint(tree.left, level + 1, output);
			preOrderPrint(tree.right , level + 1, output);
		}
		// uncomment the part below to show "null children" in the output
		else {
			String spaces = "\n";
			if (level > 0) {
				for (int i = 0; i < level - 1; i++)
					spaces += "   ";
				spaces += "|--";
			}
			output.append(spaces);
			output.append("null");
		}
	}
	/**
	 * This method calculates the difference of heights between the left and right child of a node
	 * to find the balance factor of the node
	 * From lecture notes
	 * @param n - the node whose balance factor we want
	 * @return an integer representing the balance factor of the node
	 */
	private int balanceFactor ( Node<Collision> n ) {
		//if the right child is null then the balance factor is the height of the node but negative
		if ( n.right == null )
			return -n.height;
		//if the left child is null then the balance factor is the height of the node
		if ( n.left == null )
			return n.height;
		//when node has two children the balance factor is right child height - left child height
		return n.right.height - n.left.height;
	}
	
	/**
	 * This method calculates and sets the correct height of a node
	 * From lecture notes
	 * @param n - the node we are updating
	 */
	private void updateHeight ( Node<Collision> n ) {
		//if n is the leaf then height is 0
		if (n.left==null && n.right==null)
			n.height = 0; //this is sometime set to 1
		//if the node has a right child take the right child's height and increase it by 1
		else if (n.left == null)
			n.height = n.right.height + 1;
		//if the node has a left child take the left child's height and increase it by 1
		else if (n.right == null)
			n.height = n.left.height + 1;
		//if the node has a left and right child then take the highest height of the two and add 1
		else
			n.height = Math.max( n.right.height, n.left.height) + 1;
	}
	
	/**
	 * This method makes the tree balanced by doing a right right rotation
	 * where we move the left child of B to the right of A
	 * and make A the left child of B
	 * From lecture notes
	 * 
	 * @param A - the node where the imbalance occurs
	 * @return B - the new root of subtree after changes
	 */
	private Node<Collision> balanceRR(Node<Collision> A) {
		//sets a new node B to A's right child
		Node<Collision> B=A.right;
		//set A's right child to B's left child
		A.right=B.left;
		//set B's left child to A
		B.left=A;
		//update heights of all nodes
		updateHeight(A);
		updateHeight(B);
		//return the new root after rotations
		return B;
	}
	
	/**
	 * This method makes the tree balanced by doing a left left rotation
	 * where we move the right child of B to the left of A
	 * and make A the right child of B
	 * From lecture notes
	 * 
	 * @param A - the node where the imbalance occurs
	 * @return B - the new root of subtree after changes
	 */
	private Node<Collision> balanceLL(Node<Collision> A) {
		//sets a new node B to A's left child
		Node<Collision> B=A.left;
		//set A's left child to B's right child
		A.left=B.right;
		//set B's right child to A
		B.right=A;
		//update heights of all nodes
		updateHeight(A);
		updateHeight(B);
		//return the new root after rotations
		return B;
	}
	
	/**
	 * This method makes the tree balanced by doing a right left rotation
	 * where we move the left child of C to the right of A
	 * and the right child of C to the left of B
	 * From lecture notes
	 * 
	 * @param A - the node where the imbalance occurs
	 * @return C - the new root of subtree after changes
	 */
	private Node<Collision> balanceRL(Node<Collision> A) {
		//sets a new node B to A's right child
		Node<Collision> B=A.right;
		//sets a new node C to B's left child
		Node<Collision> C=B.left;
		//set A's right child to C's left child
		A.right=C.left;
		//set B's left child to C's right child
		B.left=C.right;
		//make C root node of this subtree
		C.left=A;
		C.right=B;
		//update heights of all nodes
		updateHeight(A);
		updateHeight(B);
		updateHeight(C);
		//return the new root after rotations
		return C;
	}
	
	/**
	 * This method makes the tree balanced by doing a left right rotation
	 * where we move the left child of C to the right of B
	 * and the right child of C to the left of A
	 * From lecture notes
	 * 
	 * @param A - the node where the imbalance occurs
	 * @return C - the new root of subtree after changes
	 */
	private Node<Collision> balanceLR(Node<Collision> A) {
		//sets a new node B to A's left child
		Node<Collision> B=A.left;
		//sets a new node C to B's right child
		Node<Collision> C=B.right;
		//set A's left child to C's right child
		A.left=C.right;
		//set B's right child to C's left child
		B.right=C.left;
		//make C root node of this subtree
		C.left=B;
		C.right=A;
		//update heights of all nodes
		updateHeight(A);
		updateHeight(B);
		updateHeight(C);
		//return the new root after rotations
		return C;
	}
	//create variables to store the data of the information we need to report
	public int total=0;
	public int fatalities=0;
	public int fatalPedestrians=0;
	public int fatalCyclists=0;
	public int fatalMotorists=0;
	public int injuries=0;
	public int injuryPedestrians=0;
	public int injuryCyclists=0;
	public int injuryMotorists=0;
	
	/**
	 * Creates a formatted report including all the necessary information
	 * @param zip a string representing the zipcode
	 * @param dateBegin a date to start
	 * @param dateEnd a date to end
	 * @return report of the data we need
	 */
	public String getReport(String zip, Date dateBegin, Date dateEnd) {
		//check if zipcode is all digits
		try {
			Integer.parseInt(zip);
		}
		catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("Zipcode must be all digits");
		}
		int testZip= Integer.parseInt(zip);
		//is zipcode is not 5 digits or a negative number we throw exception
		if(zip.length() != 5 || testZip<0) {
			throw new IllegalArgumentException();
		}
		
		//set all the variables to 0
		total=0;
		fatalities=0;
		fatalPedestrians=0;
		fatalCyclists=0;
		fatalMotorists=0;
		injuries=0;
		injuryPedestrians=0;
		injuryCyclists=0;
		injuryMotorists=0;
		//call the recursive tree traverser method to calculate the data we need from the given parameters
		reportTraverser(root, zip, dateBegin, dateEnd);
		//create string report and format the string
		String report="";
		report="Motor Vehicle Collisions for zipcode "+zip+" ("+dateBegin+" - "+dateEnd+")";
		report+="\n====================================================================\n";
		//add information
		report+="Total number of collisions: "+total+"\n";
		report+="Number of fatalities: "+fatalities+"\n";
		report+="        pedestrians: "+fatalPedestrians+"\n";
		report+="           cyclists: "+fatalCyclists+"\n";
		report+="          motorists: "+fatalMotorists+"\n";
		report+="Number of injuries: "+injuries+"\n";
		report+="       pedestrians: "+injuryPedestrians+"\n";
		report+="          cyclists: "+injuryCyclists+"\n";
		report+="         motorists: "+injuryMotorists+"\n";
		//return completed report string
		return report;
	}
	/**
	 * Recursively goes down the tree to only go the necessary subtrees to find the information we need
	 * @param n the node we are looking at
	 * @param zip the zipcode we need
	 * @param dateBegin the start date
	 * @param dateEnd the end date
	 */
	private void reportTraverser(Node<Collision> n, String zip, Date dateBegin, Date dateEnd) {
		//if the node is null then we reached the end and we return
		if(n==null) {
			return;
		}
		//check if the node's zipcode matches the zipcode we are looking for
		if (n.data.getZip().compareTo(zip)==0) {
			//check if the date of the node is between the given dates
			if (n.data.getDate().compareTo(dateBegin)>=0 && n.data.getDate().compareTo(dateEnd)<=0) {
				//increment the information as needed from the node
				total+=1;
				fatalities+=n.data.getPersonsKilled();
				fatalPedestrians+=n.data.getPedestriansKilled();
				fatalCyclists+=n.data.getCyclistsKilled();
				fatalMotorists+=n.data.getMotoristsKilled();
				injuries+=n.data.getPersonsInjured();
				injuryPedestrians+=n.data.getPedestriansInjured();
				injuryCyclists+=n.data.getCyclistsInjured();
				injuryMotorists+=n.data.getMotoristsInjured();
				//traverse down the left and right children of the current node
				reportTraverser(n.left,zip,dateBegin,dateEnd);
				reportTraverser(n.right,zip,dateBegin,dateEnd);
			}
			//if the date of the node was too small we go down the right subtree
			else if(n.data.getDate().compareTo(dateBegin)<0) {
				reportTraverser(n.right,zip,dateBegin,dateEnd);
			}
			//if the date of the node was too big we go down the left subtree
			else if(n.data.getDate().compareTo(dateEnd)>0) {
				reportTraverser(n.left,zip,dateBegin,dateEnd);
			}
			
		}
		//if the zipcode was too small we go down the left subtree
		else if (n.data.getZip().compareTo(zip)>0) {
			reportTraverser(n.left,zip,dateBegin,dateEnd);
		}
		//if the zipcode was too big we go down the right subtree
		else if (n.data.getZip().compareTo(zip)<0) {
			reportTraverser(n.right,zip,dateBegin,dateEnd);
		}
		
	}
	
	
	/**
	 * Node class is used to represent nodes in a binary search tree.
	 * It contains a data item that has to implement Comparable interface
	 * and references to left and right subtrees. 
	 * 
	 * @author Joanna Klukowska
	 *
	 * @param <Collision> a reference type that implements Comparable<Collision> interface 
	 */
	protected static class Node <T extends Comparable <Collision>> 
						implements Comparable <Node <Collision> > {
	
		
		protected Node <Collision> left;  //reference to the left subtree 
		protected Node <Collision> right; //reference to the right subtree
		protected Collision data;            //data item stored in the node

		protected int height; 
		
		
		/**
		 * Constructs a BSTNode initializing the data part 
		 * according to the parameter and setting both 
		 * references to subtrees to null.
		 * @param data
		 *    data to be stored in the node
		 */
		protected Node(Collision data) {
			this.data = data;
			left = null;
			right = null;
			height = 0; 
		}
		
			
		/* (non-Javadoc)
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(Node<Collision> other) {
			return this.data.compareTo(other.data);
		} 
	
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return data.toString();
		}
		
	
		
	}
}
