package project5;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class CollisionsDataTest {

	@Test
	public void getReport() {
		SplitLineMethod splitter = new SplitLineMethod();
		String line = "1/1/2017	21:40	BROOKLYN	11230	40.6172775	-73.9666636	(40.6172775, -73.9666636)	EAST 8 STREET                   	AVENUE M		0	0	0	0	0	0	0	0	Driver Inattention/Distraction	Unspecified				3591515	SPORT UTILITY / STATION WAGON	PASSENGER VEHICLE			\r\n" + 
				"";
		ArrayList<String> testArray=new ArrayList<String>();
		testArray.add("1/1/2017");
		testArray.add("21:40");
		testArray.add("BROOKLYN");
		testArray.add("11230");
		testArray.add("40.6172775");
		testArray.add("-73.9666636");
		testArray.add("(40.6172775, -73.9666636)");
		testArray.add("EAST 8 STREET");
		testArray.add("AVENUE M");
		testArray.add("");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("0");
		testArray.add("");
		testArray.add("");
		testArray.add("");
		testArray.add("");
		testArray.add("");
		testArray.add("3591515");
		testArray.add("");
		testArray.add("");
		
		try {
			Collision testCollision = new Collision(testArray);
		}
		catch(Exception e) {
			System.err.println("No");
		}
		CollisionsData testData = new CollisionsData();
		Collision testCollision = new Collision(testArray);
		testData.add(testCollision);
		Date first = new Date("1/1/2017");
		Date second = new Date("1/25/2017");
		try {
			System.out.println(testData.getReport("", first, second));
			fail("Exception thrown incorrectly (for invalid arguments).");
		}
		catch (IllegalArgumentException e ) {
			
		}
	}

}
