package project5;

import java.util.ArrayList;

/**
 * The class creates a collision object that validates and stores the necessary values
 * and return using getters. Also overrides the compareTo and equal method.
 * 
 * @author Alice Han
 * 
 * @param entries - an ArrayList with all the values
 *
 */
public class Collision implements Comparable<Collision>{
	//private variables for Collision class
	private String zip;
	private Date date;
	private String key;
	private int personsInjured;
	private int pedestriansInjured;
	private int cyclistsInjured;
	private int motoristsInjured;
	private int personsKilled;
	private int pedestriansKilled;
	private int cyclistsKilled;
	private int motoristsKilled;
	
	/**
	 * Creates a Collision object that will store zipcode, date, key, and other information
	 * while checking if they are valid
	 * 
	 * @param entries - an ArrayList with all the values
	 * @throws IllegalArgumentException - when values are invalid
	 */
	public Collision(ArrayList<String> entries)throws IllegalArgumentException {
		//The ArrayList must not be empty must not be empty
		if (entries.isEmpty()) {
			throw new IllegalArgumentException("Empty array not allowed.");
		}
		//first element is the date and if date is incorrect exception will be thrown in date class
		try {
			date=new Date(entries.get(0));
		}
		catch(IllegalArgumentException ex) {
			throw new IllegalArgumentException("Date is invalid");
		}
		
		//check if zipcode is all digits
		try {
			Integer.parseInt(entries.get(3));
		}
		catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("Zipcode must be all digits");
		}
		//if the string contains only digits we set zip to element at index 3
		zip=entries.get(3);
		int testZip= Integer.parseInt(entries.get(3));
		//is zipcode is not 5 digits or a negative number we throw exception
		if(zip.length() != 5 || testZip<0) {
			throw new IllegalArgumentException();
		}
		//We convert the String of the values we need into integers
		try {
			personsInjured=Integer.parseInt(entries.get(10));
			personsKilled=Integer.parseInt(entries.get(11));
			pedestriansInjured=Integer.parseInt(entries.get(12));
			pedestriansKilled=Integer.parseInt(entries.get(13));
			cyclistsInjured=Integer.parseInt(entries.get(14));
			cyclistsKilled=Integer.parseInt(entries.get(15));
			motoristsInjured=Integer.parseInt(entries.get(16));
			motoristsKilled=Integer.parseInt(entries.get(17));
		}
		//if not valid integer throw exception
		catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("Invalid entry: must be non-negative integer.");
		}
		
		//Check if number of persons/pedestrians/cyclists/motorists injured/killed is a non-negative integer
		if(this.personsInjured<0 || this.personsKilled<0) {
			throw new IllegalArgumentException("Cannot be negative");
		}
				
		if(this.pedestriansInjured<0 || this.pedestriansKilled<0) {
			throw new IllegalArgumentException("Cannot be negative");
		}
		
		if(this.cyclistsInjured<0 || this.cyclistsKilled<0) {
			throw new IllegalArgumentException("Cannot be negative");
		}
		
		if(this.motoristsInjured<0 || this.motoristsKilled<0) {
			throw new IllegalArgumentException("Cannot be negative");
		}
		
		key=entries.get(23);
		//Checks if key is non-empty string and throws exception if it is empty
		if(this.key.isEmpty()){
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @return the personsInjured
	 */
	public int getPersonsInjured() {
		return personsInjured;
	}

	/**
	 * @return the pedestriansInjured
	 */
	public int getPedestriansInjured() {
		return pedestriansInjured;
	}

	/**
	 * @return the cyclistsInjured
	 */
	public int getCyclistsInjured() {
		return cyclistsInjured;
	}

	/**
	 * @return the motoristsInjured
	 */
	public int getMotoristsInjured() {
		return motoristsInjured;
	}

	/**
	 * @return the personsKilled
	 */
	public int getPersonsKilled() {
		return personsKilled;
	}

	/**
	 * @return the pedestriansKilled
	 */
	public int getPedestriansKilled() {
		return pedestriansKilled;
	}

	/**
	 * @return the cyclistsKilled
	 */
	public int getCyclistsKilled() {
		return cyclistsKilled;
	}


	/**
	 * @return the motoristsKilled
	 */
	public int getMotoristsKilled() {
		return motoristsKilled;
	}
	
	/**
	 * 
	 * Compares Collision object to another Collision object
	 * First check zip, then dates, then keys
	 * @param arg0 is the Collision object we are comparing
	 * @return the integer value result of the comparison
	 * 
	 */
	@Override
	public int compareTo(Collision arg0) {
		//Use the compareTo method to check the zipcode, the date, and the key
		int compareZip=this.zip.compareTo(arg0.getZip());
		int compareDate=this.date.compareTo(arg0.getDate());
		int compareKey=this.key.compareToIgnoreCase(arg0.getKey());
		//if we compare the zipcodes and don't get 0 then it's different and we return the compareTo value
		if(compareZip!=0)
			return compareZip;
		//if we compare the dates and don't get 0 then it's different and we return the compareTo value
		else if(compareDate!=0)
			return compareDate;
		//if we compare the keys and don't get 0 then it's different and we return the compareTo value
		else if(compareKey!=0)
			return compareKey;
		//if everything is the same return 0
		else {
			return 0;
		}
	}
	
	/**
	 * 
	 * Checks if two Collision objects are equal
	 * First check zip, then dates, then keys
	 * @return true if equal or false if not equal
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		//if the object passed in is not a Collision object we return false
		if(!(obj instanceof Collision)) {
			return false;
		}
		Collision o = (Collision) obj;
		//if the zipcodes are the same we check date, and if equal, check key while ignoring case
		if(this.zip.equals((o.getZip()))) {
			if(this.date.equals((o.getDate()))) {
				if(this.key.equalsIgnoreCase((o.getKey())))
					return true;
			}
		}
		//if the above if statement fails, return false
		return false;
	}
	
}